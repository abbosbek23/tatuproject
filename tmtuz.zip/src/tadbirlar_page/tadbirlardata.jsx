import zakovat1 from "../assets/zakovat1.jpg";
import zakovat2 from "../assets/zakovat2.jpg";
import zakovat3 from "../assets/zakovat3.jpg";
import zakovat4 from "../assets/zakovat4.jpg";
import zakovat5 from "../assets/zakovat5.jpg";
import zakovat6 from "../assets/zakovat6.jpg";
import zakovat7 from "../assets/zakovat7.jpg";
import zakovat8 from "../assets/zakovat8.jpg";
import zakovat9 from "../assets/zakovat9.jpg";
import yoshkitobxon1 from "../assets/yoshkitobxon1.jpg"
import yoshkitobxon2 from "../assets/yoshkitobxon2.jpg"
import yoshkitobxon3 from "../assets/yoshkitobxon3.jpg"
import yoshkitobxon4 from "../assets/yoshkitobxon4.jpg"
import yoshkitobxon5 from "../assets/yoshkitobxon5.jpg"
import adiblar1 from "../assets/adiblar1.jpg"
import adiblar2 from "../assets/adiblar2.jpg"
import adiblar3 from "../assets/adiblar3.jpg"
import adiblar4 from "../assets/adiblar4.jpg"
import adiblar5 from "../assets/adiblar5.jpg"
import otochirish1 from "../assets/otochirish1.jpg"
import otochirish2 from "../assets/otochirish2.jpg"
import otochirish3 from "../assets/otochirish3.jpg"
import otochirish4 from "../assets/otochirish4.jpg"
import otochirish5 from "../assets/otochirish5.jpg"
import phd1 from "../assets/phd1.jpg"
import phd2 from "../assets/phd2.jpg"
import phd3 from "../assets/phd3.jpg"

export const tadbirlar_photo = [
    {
            id: 1,
            description: "Universitetimizda \"Besh tashabbus olimpiyadasi\" doirasida \"Zakovat intellektual\" o'yinining navbatdagi turi Televizion texnologiyalari fakulteti talabalari o'rtasida bo'lib o'tdi.O'yin natijalariga ko'ra 1-o'rin Ilg'orlar jamoasi; 2-o'rin Paxtakor jamoasi;  3-o'rinni Intelekt  jamoasi egaladilar. G'olib bo'lgan jamoalarga esdalik sovg'alar va diplomlar topshirildi.",
            image:[zakovat1,zakovat2,zakovat3,zakovat4,zakovat5,zakovat6,zakovat7,zakovat8,zakovat9]  
    },
    {
            id:2,
            description:"Muhammad al-Xorazmiy nomidagi Toshkent axborot texnologiyalari universitetida “Yosh kitobxon talabalar ligasi” respublika ko'rik-tanlovining universitet bosqichi bo'lib o'tdi.Tanlovning asosiy maqsadi –  talabalar o'rtasida badiiy asarlarning hayotimizdagi o'rni va ahamiyatini targ'ib qilish orqali yoshlarimizni har tomonlama sog‘lom va barkamol etib  tarbiyalash.Bellashuv yakuniga ko‘ra quyidagi natijalar qayd etildi:1-o‘rinni  AKT sohasida iqtisodiyot va menejment fakulteti jamoasi.2-o‘rinni Televizion texnologiyalar fakulteti jamoasi.3-o‘rinni Kiberxavfsizlik fakulteti jamoasi egaladi.G'olib bo'lgan talabalar diplom hamda esdalik sovg‘alar bilan taqdirlandilar.",
            image:[yoshkitobxon1,yoshkitobxon2,yoshkitobxon3,yoshkitobxon4,yoshkitobxon5]
    },
    {
            id:3,
            description:"Bugun, Muhammad al-Xorazmiy nomidagi Toshkent axborot texnologiyalari universiteti Televizion texnologiyalar fakulteti jamoasi ishtirokida \"Atoqli o'zbek yozuvchisi, dramaturgi Said Ahmad va shoira Saida Zunnunovalar\"ning hayoti va ijodiga bag‘ishlab ma’naviy-ma'rifiy tadbir tashkil etildi. Tadbirda ustozlar tomonidan adiblarning mashaqqatli lekin sharafli hayot yoʻlini, o‘zbek milliy adabiyotiga qo‘shgan ulkan hissalarini, millatimiz ravnaqi yo‘lida qilgan fidokorona xizmatlarini yoshlarga tanishtirib ularga ibrat sifatida targʻib qilindi. Mazkur tadbir doirasida talabalar adib va adibalarning hayoti va ijodi haqida professor-o'qituvchilar ma'ruzalari orqali to'liq ma'lumotlar olishdi. Shunigdek Adiblar xiyobonida o‘tkazilgan tadbirda turli xil ko'ngil ochar o'yinlar va sport musobaqalari tashkil etildi.",
            image:[adiblar1,adiblar2,adiblar3,adiblar4,adiblar5]
    },
    {
        id: 4,
        description: "Muhammad al-Xorazmiy nomidagi Toshkent axborot texnologiyalari universiteti va O‘zbekiston Respublikasi Favqulodda vaziyatlar Vazirligi Fuqaro muhofazasi instituti bilan hamkorlikda \"Favqulodda vaziyatlarda to‘g‘ri harakatlanish va fuqaro muhofazasi\" bo‘yicha bilimlarini oshirish hamda tayyorgarlik ko‘rish bo‘yicha malaka oshirish darslari tashkil etildi.",
        image: [otochirish1, otochirish2, otochirish3, otochirish4, otochirish5]
   },
   {
        id:5,
        description:"Kafedramiz o’qituvchisi Ismailov Kamolitdin Saidaxmadovichning “Zamonaviy o‘zbek hujjatli kinosida film-portret janri” mavzusida 17.00.03 – Kino san’ati. Televideniye ixtisosligi bo‘yicha falsafa doktori (PhD) ilmiy darajasini olish uchun yozilgan dissertatsiya ishini muvaffaqiyatli himoya qildi!",
        image:[phd1,phd2,phd3]      
   }
]